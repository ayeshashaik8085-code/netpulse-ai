# NetPulse AI — Starter Project

## What this prototype does
- Creates simulated network measurements.
- Lets you choose normal, traffic-spike, high-packet-loss, high-latency, and mixed scenarios.
- Uses Isolation Forest (scikit-learn) to flag unusual samples.
- Shows interactive charts and lets you download the analysed data as CSV.
- Uses a web interface that adapts to mobile and desktop screens.

## Important limitation
This first version uses simulated data. It does not monitor live traffic from your phone or college network. An anomaly flag is not proof of an attack or a network failure.

## Files
- `app.py`: application code
- `requirements.txt`: Python packages needed for deployment

## Deploy using Streamlit Community Cloud
1. Create/sign in to GitHub and create a repository named `netpulse-ai`.
2. Upload `app.py` and `requirements.txt` to the repository root.
3. Open https://share.streamlit.io/ and sign in with GitHub.
4. Choose **Create app**, select the repository and branch, and set the main file to `app.py`.
5. Deploy and wait for the app to start. The host will provide a shareable `streamlit.app` URL.

See official instructions: https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/deploy

## Demo suggestions
1. Select `Normal traffic`.
2. Select `Traffic spike`.
3. Select `High packet loss`.
4. Select `High latency`.
5. Compare the charts and AI-flagged samples.
6. Explain that these are controlled simulations, not real network captures.
